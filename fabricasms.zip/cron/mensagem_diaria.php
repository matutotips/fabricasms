<?php

include __DIR__.'/../includes/includes.php';

$tlg = new Telegram (6668016259:AAG3YkV3ZzU6n4QIAFtYKg6eE-Jglrm3TSA);

$tlg->sendMessage ([
'GRUPO_ID' => '@fabricasms',
'text' => "<b>🤓 RECEBA SMS COM NÚMEROS NOVOS PARA CRIAR CONTAS</b>

- Telegram
- Whatsapp
- Instagram
- Facebook
- E muitos outros...

💬 Receba os códigos no nosso bot
@fabricasms

🌐 Canal de Referências
@fabricasms
📍 Nosso grupo
@fabricasms

*Preço e serviço incomparável com os existentes.
*Mais de 4 mil números disponíveis",
'parse_mode' => 'html'
]);