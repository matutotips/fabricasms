<?php

include __DIR__.'/../includes/includes.php';

$tlg = new Telegram ('6668016259:AAG3YkV3ZzU6n4QIAFtYKg6eE-Jglrm3TSA');

print_r ($tlg->sendDocument ([
	'chat_id' => @itachisms2,
	'caption' => "Backup\n@itachisms2\n".date ('d/m/Y H:i:s'),
	'document' => curl_file_create (__DIR__.'/../recebersmsbot.db')
]));