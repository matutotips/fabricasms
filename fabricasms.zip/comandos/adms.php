<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>Olá meus adms disponível no momento são\n @icarowinraio e @fabricasms</b>",
	'parse_mode' => 'html'
]);