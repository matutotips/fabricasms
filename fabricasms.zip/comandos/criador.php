<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>📜 · @fabricasmsbot \n\n ▫️ · SUPORTE: @icarowinraio</b>",
	'parse_mode' => 'html'
]);