<?php

$tlg = new Telegram (TOKEN_BOT);
$bd_tlg = new bdTelegram (__DIR__.'/../recebersmsbot.db');

$msg = @$tlg->sendMessage ([
    'chat_id' => $usuario ['id_telegram'],
    'text' => "😀 <b>Gere números para receber SMS no seu serviço preferido, Facebook, Instagram, Whatapp, Telegram...</b>\n\n📍É facíl, apenas recarregue sua conta com o comando /recarregar e use o saldo para comprar números, não se preocupe você só paga depois que recebe o sms!\n\n<u>Escolha um serviço para receber SMS com /servicos\n\nCaso esteja com divida para saber se eh confiavel, olhe nosso canal de referencias: @fabricasms\n\nCaso tenha alguma divida chame o suporte: @icarowinraio </u>",
    'parse_mode' => 'html'
]);